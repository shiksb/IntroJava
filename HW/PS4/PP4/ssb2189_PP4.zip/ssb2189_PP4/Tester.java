//------------------------------------------------------//
//Author: Shikhar Bakhda
//UNI: ssb2189
//Tester.java
//This class contains main() and tests the Game class
//------------------------------------------------------//
public class Tester{
    public static void main(String[] args) {

    Game game = new Game(); //creating new Game object
    game.play(); //game.play() contains the main UI
    }
}
